# Author:wjy
# CreatTime: 2024/6/3
# FileName: util
# Description: simple introduction of the code
import csv
import hashlib
import math
import random

import numpy as np
import torch
# from main_amhmda import *
from main_hmdd20 import *



np.random.seed(args.seed)
torch.manual_seed(args.seed)            # 为CPU设置随机种子
torch.cuda.manual_seed(args.seed)       # 为当前GPU设置随机种子
torch.cuda.manual_seed_all(args.seed)


def set_seed(seed=50):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

#节点着色算法
class MethodWLNodeColoring:
    def __init__(self,args,dim):
        self.dim=dim  #878
        self.data = None
        self.max_iter = args.wl_max_iter
        self.node_color_dict = {}
        self.node_neighbor_dict = {}

    def setting_init(self, node_list, link_list):#节点和连接信息
        for node in node_list:
            #为每个节点的颜色初始化为1，并添加到字典
            self.node_color_dict[node] = 1
            #为每个节点初始化一个空的邻居字典，并添加进去
            self.node_neighbor_dict[node] = {}

        for pair in link_list:#遍历每对链接 link_list为正样本的位置索引
            u1, u2 = pair
            if u1 not in self.node_neighbor_dict:
                self.node_neighbor_dict[u1] = {}
            if u2 not in self.node_neighbor_dict:
                self.node_neighbor_dict[u2] = {}
            #遍历连接列表，对于每对连接 (u1, u2)，将它们添加到彼此的邻居字典中，表示它们之间存在连接关系。
            self.node_neighbor_dict[u1][u2] = 1
            self.node_neighbor_dict[u2][u1] = 1

    def WL_recursion(self, node_list):
        iteration_count = 1 #初始化迭代器次数
        while True:
            new_color_dict = {} #初始化一个新字典，用于存储节点的新颜色
            for node in node_list:
                neighbors = self.node_neighbor_dict[node]
                neighbor_color_list = [self.node_color_dict[neb] for neb in neighbors]#获取邻居颜色
                #当前节点和邻居节点的颜色字符串连接
                color_string_list = [str(self.node_color_dict[node])] + sorted([str(color) for color in neighbor_color_list])
                color_string = "_".join(color_string_list)
                hash_object = hashlib.md5(color_string.encode())#创建一个MD5哈希对象，用于计算颜色字符串的哈希值
                hashing = hash_object.hexdigest()#计算颜色字符串的希哈值，并转化为十六进制
                new_color_dict[node] = hashing
            #构建一个颜色索引字典，将哈希值映射到索引，索引从 1 开始。
            color_index_dict = {k: v+1 for v, k in enumerate(sorted(set(new_color_dict.values())))}
            for node in new_color_dict:
                new_color_dict[node] = color_index_dict[new_color_dict[node]] #将节点颜色更新为对应索引
            if self.node_color_dict == new_color_dict or iteration_count == self.max_iter:#颜色更新完毕，或者达到最大索引次数
                for i in range(self.dim):
                    tmp_list=[]
                    for l in range(int(self.dim / 2)):
                        tmp_list.append(math.sin(self.node_color_dict[i]/math.pow(10000,float(2*l)/self.dim)))
                        tmp_list.append(math.cos(self.node_color_dict[i]/math.pow(10000,float(2*l+1)/self.dim)))
                    if self.dim%2==1:
                        tmp_list.append(math.sin(self.node_color_dict[i]/float(10000)))
                    #计算出来的新的颜色的值，作为节点的新颜色存储
                    self.node_color_dict[i]=np.array(tmp_list).reshape(1,-1)

                return
            else:
                self.node_color_dict = new_color_dict
            iteration_count += 1

    def run(self,md):
        # link_list=np.load(father_path+ '/data/'+self.datasort+'/positive_ij.npy').tolist()
        # link_list = np.mat(np.where(md == 1)).T.tolist()
        tmp_positive_position = np.where(md == 1)
        len_tmp_pos = len(tmp_positive_position[0])
        positive_position=[]
        for i in range(len_tmp_pos):
            if tmp_positive_position[0][i] < tmp_positive_position[1][i]:
                positive_position.append([tmp_positive_position[0][i], tmp_positive_position[1][i]])
        # link_list=positive_position.t().tolist()
        node_list=[i for i in range(self.dim)]

        self.setting_init(node_list, positive_position)
        self.WL_recursion(node_list)
        return self.node_color_dict

def normalized_laplacian(adj_matrix):
    R = np.sum(adj_matrix, axis=1) + 1
    R_sqrt = 1 / np.sqrt(R)
    D_sqrt = np.zeros((R_sqrt.shape[0], R_sqrt.shape[0]))
    for i in range(R_sqrt.shape[0]):
        D_sqrt[i][i] = R_sqrt[i]
    I = np.eye(adj_matrix.shape[0])
    return I - np.matmul(np.matmul(D_sqrt, adj_matrix), D_sqrt)

def test_features_choose(rel_adj_mat, features_embedding,args):
    rel_adj_mat = rel_adj_mat.detach().cpu().numpy()
    rna_nums, dis_nums = rel_adj_mat.shape[0], rel_adj_mat.shape[1]
    features_embedding_rna = features_embedding[0:rna_nums, :]
    features_embedding_dis = features_embedding[rna_nums:features_embedding.size()[0], :]
    test_features_input, test_lable = [], []

    for i in range(rna_nums):
        for j in range(dis_nums):
            test_features_input.append((features_embedding_rna[i, :] * features_embedding_dis[j, :]).unsqueeze(0))
            test_lable.append(rel_adj_mat[i, j])

    test_features_input = torch.cat(test_features_input, dim=0)
    test_lable = torch.FloatTensor(np.array(test_lable)).unsqueeze(1)
    
    return test_features_input.to(args.device), test_lable

def balance_samples(m_d): #1444*1444
    tmp_positive_position=np.where(m_d==1)
    tmp_negative_position=np.where(m_d==0)
    len_tmp_pos=len(tmp_positive_position[0])
    len_tmp_neg=len(tmp_negative_position[1])
    positive_ij=np.array(tmp_positive_position,dtype=int).T #12446,2
    tmp_negative=np.array(tmp_negative_position,dtype=int).T
    np.random.shuffle(positive_ij)
    np.random.shuffle(tmp_negative)
    negative_ij = tmp_negative[:len_tmp_pos, :]  # 平衡正负样本集
    return positive_ij ,negative_ij


def get_gaussian(adj):
    Gaussian = np.zeros((adj.shape[0], adj.shape[0]), dtype=np.float32)
    gamaa = 1
    sumnorm = 0
    for i in range(adj.shape[0]):
        norm = np.linalg.norm(adj[i]) ** 2
        sumnorm = sumnorm + norm
    gama = gamaa / (sumnorm / adj.shape[0])
    for i in range(adj.shape[0]):
        for j in range(adj.shape[0]):
            Gaussian[i, j] = math.exp(-gama * (np.linalg.norm(adj[i] - adj[j]) ** 2))

    return Gaussian

def plot_prc_curves(precisions, recalls, auprs):
    mean_recall = np.linspace(0, 1, 1000)
    precision = []
    #plt.style.use('ggplot')
    for i in range(len(recalls)):
        precision.append(np.interp(1-mean_recall, 1-recalls[i], precisions[i]))
        precision[-1][0] = 1.0
        plt.plot(recalls[i], precisions[i], alpha=0.8, label='ROC fold %d (AUPR = %.4f)' % (i + 1, auprs[i]))

    mean_precision = np.mean(precision, axis=0)
    mean_precision[-1] = 0
    # mean_prc = metrics.auc(mean_recall, mean_precision)
    mean_prc = np.mean(auprs)
    prc_std = np.std(auprs)
    plt.plot(mean_recall, mean_precision, color='b', alpha=0.8,
             label='Mean AUPR (AUPR = %.4f $\pm$ %.4f)' % (mean_prc, prc_std))  # AP: Average Precision
    # filename = "../PT/m_r.csv"
    # # 打开文件，以写入模式写入数据
    # with open(filename, 'w', newline='') as csvfile:
    #     # 创建CSV写入器
    #     writer = csv.writer(csvfile)
    #     # 写入列表中的每个元素
    #     for item in mean_recall:
    #         writer.writerow([item])
    #
    # filename = "../PT/m_p.csv"
    # # 打开文件，以写入模式写入数据
    # with open(filename, 'w', newline='') as csvfile:
    #     # 创建CSV写入器
    #     writer = csv.writer(csvfile)
    #     # 写入列表中的每个元素
    #     for item in mean_precision:
    #         writer.writerow([item])
    plt.plot([-0.05, 1.05], [1.05, -0.05], linestyle='--', color='navy', alpha=0.4)
    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel('Recall')
    plt.ylabel('Precision')
    plt.title('PR curve')
    plt.rcParams.update({'font.size': 10})
    plt.legend(loc='lower left', prop={"size": 8})
    plt.savefig('./pr.jpg', dpi=1200, bbox_inches='tight')
    plt.show()

def plot_auc_curves(fprs, tprs, aucs):
    mean_fpr = np.linspace(0, 1, 1000)
    tpr = []
    #plt.style.use('ggplot')
    for i in range(len(fprs)):
        tpr.append(np.interp(mean_fpr, fprs[i], tprs[i]))
        tpr[-1][0] = 0.0
        plt.plot(fprs[i], tprs[i], alpha=0.8, label='ROC fold %d (AUC = %.4f)' % (i + 1, aucs[i]))

    mean_tpr = np.mean(tpr, axis=0)
    mean_tpr[-1] = 1.0
    mean_auc = np.mean(aucs)
    auc_std = np.std(aucs)
    plt.plot(mean_fpr, mean_tpr, color='b', alpha=0.8, label='Mean AUC (AUC = %.4f $\pm$ %.4f)' % (mean_auc, auc_std))
    filename = "../PT/m_f.csv"

    #    # 打开文件，以写入模式写入数据
    # with open(filename, 'w', newline='') as csvfile:
    #        # 创建CSV写入器
    #        writer = csv.writer(csvfile)
    #        # 写入列表中的每个元素
    #        for item in mean_fpr:
    #            writer.writerow([item])
    #
    # filename = "../PT/m_t.csv"
    #    # 打开文件，以写入模式写入数据
    # with open(filename, 'w', newline='') as csvfile:
    #        # 创建CSV写入器
    #        writer = csv.writer(csvfile)
    #        # 写入列表中的每个元素
    #        for item in mean_tpr:
    #            writer.writerow([item])
    plt.plot([-0.05, 1.05], [-0.05, 1.05], linestyle='--', color='navy', alpha=0.4)

    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('ROC curve')
    plt.rcParams.update({'font.size': 10})
    plt.legend(loc='lower right', prop={"size": 8})
    plt.savefig('./auc.jpg', dpi=1200, bbox_inches='tight')
    plt.show()

def get_edge_index(ma):
    edge_index = [[], []]
    for i in range(len(ma[0])):
        for j in range(len(ma[1])):
            if ma[i][j] != 0:
                edge_index[0].append(i)
                edge_index[1].append(j)
    return torch.LongTensor(edge_index)


class MLPClassifier(nn.Module):
    def __init__(self, input_dim,device):
        super(MLPClassifier, self).__init__()
        self.device = device
        self.model = nn.Sequential(
            nn.Linear(input_dim, input_dim//2),
            nn.LeakyReLU(),
            nn.Linear(input_dim//2, input_dim//4),
            nn.LeakyReLU(),
            nn.Linear(input_dim//4, input_dim//8),
            nn.LeakyReLU(),
            nn.Linear(input_dim//8, input_dim // 16),
            nn.LeakyReLU(),
            nn.Linear(input_dim // 16, 2),
            nn.Softmax(dim=1)
        )
        self.to(self.device)

    def fit(self, X, y, epochs=200, lr=0.0001):
        X = torch.tensor(X, dtype=torch.float32).to(self.device)
        y = torch.tensor(y, dtype=torch.long).to(self.device)

        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(self.parameters(), lr=lr)

        self.train()
        for epoch in range(epochs):
            optimizer.zero_grad()
            outputs = self.model(X)
            loss = criterion(outputs, y)
            loss.backward()
            optimizer.step()

    def predict_proba(self, X):
        X = torch.tensor(X, dtype=torch.float32).to(self.device)
        self.eval()
        with torch.no_grad():
            outputs = self.model(X)
        return outputs.cpu().numpy()