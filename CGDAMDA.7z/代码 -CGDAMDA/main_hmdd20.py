# This is a sample Python script.
import argparse
import parser
import random

import numpy as np
import pandas as pd
from sklearn.ensemble import AdaBoostClassifier, RandomForestClassifier, \
    GradientBoostingClassifier
from sklearn.metrics import roc_auc_score, precision_recall_curve, auc, accuracy_score, f1_score, recall_score, \
    precision_score, matthews_corrcoef, roc_curve
from sklearn.model_selection import KFold
from sklearn.neural_network import MLPClassifier
from sklearn.tree import DecisionTreeClassifier
from torch import optim

from torch.utils.data import TensorDataset, DataLoader

from model import *
import torch as t
from util import *
from train_test import *


# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.





parser = argparse.ArgumentParser()
parser.add_argument('--lr',default=0.0001,type=float)
parser.add_argument('--wd', type=float, default=1e-3, help='weight_decay')
parser.add_argument('--step_size',default=50,type=float)
parser.add_argument('--gamma',default=0.8,type=float)
parser.add_argument('--epochs',default=500,type=int)
parser.add_argument('--encoder_layers',default=4,type=int)




parser.add_argument('--drop_rate',default=0.2,type=float)
# parser.add_argument('--dropout',default=0.01,type=float)
# parser.add_argument('--subgraph_size',default=6,type=int)
parser.add_argument('--device',default="cuda",help="device for training /testing")
parser.add_argument('--seed',default=1,type=int)
parser.add_argument('--kfolds', default=5, type=int)
parser.add_argument('--wl_max_iter', default=2, type=int)
parser.add_argument('--dataset', default='HMDD v2.0', help='dataset')




args = parser.parse_args()
args.dd2 = True
args.data_dir = 'dataset/'+ args.dataset + '/'

# np.random.seed(args.seed)
# torch.manual_seed(args.seed)            # 为CPU设置随机种子
# torch.cuda.manual_seed(args.seed)       # 为当前GPU设置随机种子
# torch.cuda.manual_seed_all(args.seed)

random.seed(args.seed)
np.random.seed(args.seed)
torch.manual_seed(args.seed)
torch.cuda.manual_seed(args.seed)
torch.cuda.manual_seed_all(args.seed)
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False


if __name__ == '__main__':
    dataset = dict()
    mf = np.loadtxt(args.data_dir + 'miRNA functional similarity matrix.txt', dtype=float) #788*788
    # ds = np.loadtxt(args.data_dir + 'disease semantic similarity matrix.txt', dtype=float) #374*374
    ds1 = np.loadtxt(args.data_dir + 'disease semantic similarity matrix 1.txt', dtype=float)
    ds2 = np.loadtxt(args.data_dir + 'disease semantic similarity matrix 2.txt', dtype=float)
    ds = (ds1 + ds2) / 2
    dataset['m_fs'] = mf
    dataset['m_fs_index'] = get_edge_index(mf)
    dataset['d_ss'] = ds
    dataset['d_ss_index'] = get_edge_index(ds)
    dataset['d_num'] = len(np.loadtxt(args.data_dir + 'disease number.txt', delimiter='\t', dtype=str))
    dataset['m_num'] =len( np.loadtxt(args.data_dir + 'miRNA number.txt', delimiter='\t', dtype=str))
    dataset['two-pair'] = np.loadtxt(args.data_dir + 'known disease-miRNA association number.txt', dtype=int) - 1 #8968*2
    args.miRNA_number = dataset['m_num']
    args.disease_number = dataset['d_num']

    m_d = np.zeros((dataset['m_num'],dataset['d_num']))
    for i in range(len(dataset['two-pair'])):
        x,y = dataset['two-pair'][i]

        m_d[x][y] = 1

    dataset['m_d'] = m_d

    gm = get_gaussian(dataset['m_d'])
    gm_edge_index = get_edge_index(gm)
    gd = get_gaussian(dataset['m_d'].transpose())
    gd_edge_index = get_edge_index(gd)
    dataset['m_gs'] = gm
    dataset['m_gs_index'] = gm_edge_index
    dataset['d_gs'] = gd
    dataset['d_gs_index'] = gd_edge_index



    md = np.zeros((dataset['m_d'].shape[0]+dataset['m_d'].shape[1],dataset['m_d'].shape[0]+dataset['m_d'].shape[1])) #1162*1162
    md[:dataset['m_d'].shape[0],dataset['m_d'].shape[0]:] = dataset['m_d']
    md[dataset['m_d'].shape[0]:, :dataset['m_d'].shape[0]] = dataset['m_d'].T


    tmp_wl = MethodWLNodeColoring(args, md.shape[0]).run(md)
    WL_embed_matrix = np.zeros((md.shape[0], md.shape[0]))  # 641*641
    for i in range(md.shape[0]):  # 641*641
        WL_embed_matrix[i] = tmp_wl[i]

    dataset['WL'] = WL_embed_matrix
    lap_matrix = normalized_laplacian(md)
    for i in range(md.shape[0]):
        lap_matrix[i, i] = 0
    dataset['lap'] = lap_matrix





    position_ij,negative_ij = balance_samples(dataset['m_d']) #5430*2
    all_index = np.vstack((position_ij,negative_ij)) #
    all_lables = np.array([1] * len(position_ij) + [0] * len(negative_ij), dtype=int)#24892
    # samples = np.concatenate((all_index, np.expand_dims(all_lables, axis=1)), axis=1) #24892,3

    dataset['m_d'] = t.FloatTensor(dataset['m_d']).to(args.device)
    dataset['d_gs'] = t.FloatTensor(dataset['d_gs']).to(args.device)
    dataset['d_ss'] = t.FloatTensor(dataset['d_ss']).to(args.device)
    dataset['m_gs'] = t.FloatTensor(dataset['m_gs']).to(args.device)
    dataset['m_fs'] = t.FloatTensor(dataset['m_fs']).to(args.device)
    dataset['m_fs_index'] = t.LongTensor(dataset['m_fs_index']).to(args.device)
    dataset['m_gs_index'] = t.LongTensor(dataset['m_gs_index']).to(args.device)
    dataset['d_ss_index'] = t.LongTensor(dataset['d_ss_index']).to(args.device)
    dataset['d_gs_index'] = t.LongTensor(dataset['d_gs_index']).to(args.device)

    ## the squence shuffle
    index = [i for i in range(len(all_index))]
    random.shuffle(index)
    shuffle_index = all_index[index]
    shuffle_lables = all_lables[index]

    AUC_list = []
    AUPR_list = []
    ACC_list = []
    F1_list = []
    pre_list = []
    recall_list = []
    mcc_list = []
    tprs = []
    fprs = []
    precisions = []
    recalls = []

    kf = KFold(n_splits=args.kfolds, shuffle=True, random_state=args.seed)
    train_idx, valid_idx = [], []
    for train_index, valid_index in kf.split(shuffle_index):
        train_idx.append(train_index) #5,7683  4是7684
        valid_idx.append(valid_index)
    for k in range(args.kfolds):
        print("="*10+"fold_"+str(k+1)+" train start "+"="*10)



        # train_matrix = np.matrix(dataset['m_d'], copy=True) #447*218


        # train_matrix = torch.from_numpy(train_matrix).to(torch.float32)
        # train_matrix = train_matrix.to(args.device)

        # dataset['m_d'] = t.FloatTensor(dataset['m_d']).to(args.device)


        model = Fusion(dataset['d_num']+dataset['m_num'],args).to(args.device)

        optimizer = optim.Adam(model.parameters(), weight_decay=args.wd, lr=args.lr)
        # scheduler = t.optim.lr_scheduler.StepLR(optimizer, step_size=args.step_size, gamma=args.gamma)

        #1444*1024
        sum_x = train(model, dataset,  optimizer, args)
        # predict_score, label = test_features_choose(dataset['m_d'] , sum_x,args)

        train_index = shuffle_index[train_idx[k]]
        train_emb = torch.empty(0).to(args.device)
        for i in range(len(train_index)):  #19913*2
            a = torch.cat((sum_x[train_index[i][0]], (sum_x[train_index[i][1]+dataset['m_num']])), dim=0).unsqueeze(0) #1*(1024*2)
            train_emb = torch.cat((train_emb, a), dim=0)

        classfier = 'XGBoost'
        assert classfier in ['AdaBoost','XGBoost','RandomForest','MLP','GBDT'],"the classfier is not exist!"
        if classfier == 'AdaBoost':
            model_classfier = AdaBoostClassifier(estimator=DecisionTreeClassifier(max_depth=5))
        elif classfier == 'XGBoost' :
            model_classfier = xgb.XGBClassifier(
                learning_rate=0.1,
                n_estimators=300,
                max_depth=5,
                reg_alpha=0.001,
                reg_lambda=0.1
            )
        elif classfier == 'RandomForest' :
            # model_classfier = RandomForestClassifier(n_estimators=500, max_depth=7)
            model_classfier = RandomForestClassifier(n_estimators=300, max_depth=5)
        elif classfier == 'MLP' :
            model_classfier = MLPClassifier(1024*2,args.device)
            # model_classfier = MLPClassifier(solver='adam', hidden_layer_sizes=(512, 2), activation='LeakyReLU', learning_rate_init=0.0001)
        elif classfier =='GBDT' :
            model_classfier = GradientBoostingClassifier(n_estimators=100, max_depth=10)
        # model_xgb = AdaBoostClassifier(estimator=DecisionTreeClassifier(max_depth=5))
        # model_xgb = GradientBoostingRegressor(max_depth=5, n_estimators=300)
        train_embding = train_emb.detach().cpu().numpy()
        # predict_score1=predict_score.detach().cpu().numpy()
        # lable1 = label.numpy()
        model_classfier.fit(train_embding, shuffle_lables[train_idx[k]])
        # train(model,tr_set , dataset, rna_len, dis_len, optimizer,args)
        print("=" * 10 + "fold_" + str(k+1) + " train finished " + "=" * 10)

        print("=" * 10 + "fold_" + str(k+1) + " test start " + "=" * 10)
        # labels, preds,valid_emb = test( model,shuffle_index[valid_idx[k]],shuffle_lables[valid_idx[k]] , dataset,rna_len,dis_len, args)
        test_sum_x = test(model,  dataset, args)

        valid_index = shuffle_index[valid_idx[k]]
        valid_emb = torch.empty(0).to(args.device)
        for i in range(len(valid_index)):  # 19913*2
            a = torch.cat((test_sum_x[valid_index[i][0]], (test_sum_x[valid_index[i][1] + dataset['m_num']])), dim=0).unsqueeze(
                0)  # 1*(1024*2)
            valid_emb = torch.cat((valid_emb, a), dim=0)

        valid_embding = valid_emb.detach().cpu().numpy()
        y_pred_proba = model_classfier.predict_proba(valid_embding )[:,1]
        print(y_pred_proba.shape)
        labels = shuffle_lables[valid_idx[k]]
        # labels, preds = test(model,tt_set, dataset, rna_len,dis_len, args)

        fpr, tpr, thresholds = roc_curve(labels, y_pred_proba)
        tprs.append(tpr)
        fprs.append(fpr)
        # 选择最佳阈值
        # optimal_idx = np.argmax(tpr - fpr)
        # optimal_threshold = thresholds[optimal_idx]
        # print("Best threshold：{:.4f}".format(optimal_threshold))



        AUC = roc_auc_score(labels, y_pred_proba)
        AUC_list.append(AUC)

        precision, recall1, _ = precision_recall_curve(labels, y_pred_proba) #返回的也是根据不同阈值产生的值，是列表
        precisions.append(precision)
        recalls.append(recall1)
        AUPR = auc(recall1, precision) #auc函数求得曲线下面积 这里是PR曲线
        AUPR_list.append(AUPR)
        pred = np.array([1 if p > 0.5 else 0 for p in y_pred_proba])
        ACC = accuracy_score(labels, pred)
        ACC_list.append(ACC)
        mcc = matthews_corrcoef(labels, pred)
        mcc_list.append(mcc)
        F1= f1_score(labels,pred)
        F1_list.append(F1)
        recall = recall_score(labels,pred)
        recall_list.append(recall)
        pre = precision_score(labels,pred)
        pre_list.append(pre)
        print("fold_"+str(k+1)+" result "+"AUC:{:.4f}, AUPR:{:.4f}, ACC:{:.4f}, F1:{:.4f},recall:{:.4f},pre:{:.4f},mcc:{:.4f}".format(AUC, AUPR, ACC,F1,recall,pre,mcc))
        print("=" * 10 + "fold_" + str(k + 1) + " test end " + "=" * 10)

    print("model Train and Test Finished")
    plot_auc_curves(fprs, tprs, AUC_list)
    plot_prc_curves(precisions, recalls, AUPR_list)
    rna_x1 = sum_x[:dataset['m_num']].detach().cpu().numpy()
    dis_x1 = sum_x[dataset['m_num']:].detach().cpu().numpy()
    rna_x1 = pd.DataFrame(rna_x1)
    dis_x1 = pd.DataFrame(dis_x1)
    filename1 = "d_r.xlsx"
    dis_x1.to_excel(filename1, index=False, header=False)
    filename2 = "m_r.xlsx"
    rna_x1.to_excel(filename2, index=False, header=False)

    AUC_mean=np.mean(AUC_list)
    AUPR_mean = np.mean(AUPR_list)
    ACC_mean = np.mean(ACC_list)
    F1_mean = np.mean(F1_list)
    recall_mean = np.mean(recall_list)
    pre_mean = np.mean(pre_list)
    mcc_mean = np.mean(mcc_list)
    AUC_std = np.std(AUC_list)
    AUPR_std = np.std(AUPR_list)
    ACC_std = np.std(ACC_list)
    F1_std = np.std(F1_list)
    recall_std = np.std(recall_list)
    pre_std = np.std(pre_list)
    mcc_std = np.std(mcc_list)
    print(  "AUC-mean:{:.4f}, AUPR-mean:{:.4f}, ACC-mean:{:.4f}, F1-mean:{:.4f}, recall-mean:{:.4f}, pre-mean:{:.4f},mcc-mean:{:.4f}"
          .format(AUC_mean,AUPR_mean,ACC_mean,F1_mean,recall_mean,pre_mean,mcc_mean))
    print("AUC_std:{:.4f}, AUPR_std:{:.4f}, ACC_std:{:.4f}, F1_std:{:.4f}, recall_std:{:.4f}, pre_std:{:.4f},mcc_std:{:.4f}"
          .format(AUC_std, AUPR_std, ACC_std, F1_std, recall_std, pre_std, mcc_std))













