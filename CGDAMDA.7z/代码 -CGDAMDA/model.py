# Author:wjy
# CreatTime: 2024/6/3
# FileName: model
# Description: simple introduction of the code
import numpy as np
import torch
from einops.layers.torch import Rearrange
# from timm.layers import DropPath
from torch import nn
from torch_geometric.nn import GCNConv


class SpatialAttention(nn.Module):
    def __init__(self):
        super(SpatialAttention, self).__init__()
        self.sa = nn.Conv2d(2, 1, 7, padding=3, padding_mode='reflect', bias=True)

    def forward(self, x):
        x_avg = torch.mean(x, dim=1, keepdim=True) #1*2*495*495--1*1*495*495
        x_max, _ = torch.max(x, dim=1, keepdim=True)
        x2 = torch.cat([x_avg, x_max], dim=1) #1*2*495*495
        sattn = self.sa(x2)
        return sattn


class ChannelAttention(nn.Module):
    def __init__(self, dim, reduction):
        super(ChannelAttention, self).__init__()
        self.gap = nn.AdaptiveAvgPool2d(1)

        self.ca = nn.Sequential(
            nn.Conv2d(dim, dim *reduction, 1, padding=0, bias=True),
            nn.ReLU(inplace=True),
            nn.Conv2d(dim * reduction, dim, 1, padding=0, bias=True),
        )

    def forward(self, x):
        x_gap = self.gap(x) #1*2*495*495
        cattn = self.ca(x_gap)
        return cattn


class PixelAttention(nn.Module):
    def __init__(self, dim):
        super(PixelAttention, self).__init__()
        self.pa2 = nn.Conv2d(2 * dim, dim, 1, padding=0, padding_mode='reflect', groups=dim, bias=True)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x, pattn1):
        B, C, H, W = x.shape  #1*2*495*495
        x = x.unsqueeze(dim=2)  # B, C, 1, H, W
        pattn1 = pattn1.unsqueeze(dim=2)  # B, C, 1, H, W
        x2 = torch.cat([x, pattn1], dim=2) #853*1*2*1*853 # B, C, 2, H, W
        x2 = Rearrange('b c t h w -> b (c t) h w')(x2) #853*2*1*853
        pattn2 = self.pa2(x2) #853*1*1*853
        pattn2 = self.sigmoid(pattn2)
        return pattn2


class CGAFusion(nn.Module):
    def __init__(self, dim, reduction=2):
        super(CGAFusion, self).__init__()
        self.sa = SpatialAttention()
        self.ca = ChannelAttention(dim, reduction)#
        self.pa = PixelAttention(dim)
        self.conv = nn.Conv2d(dim, 1, 1, bias=True)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x, y):
        initial = x + y  #1*2*495*495
        cattn = self.ca(initial) #1*2*1*1
        sattn = self.sa(initial) #1*1*495*495
        pattn1 = sattn + cattn  #1*2*495*495
        pattn2 = self.sigmoid(self.pa(initial, pattn1)) #1*2*495*495
        result = initial + pattn2 * x + (1 - pattn2) * y
        result = self.conv(result)
        return result



class DilateBlock(nn.Module):
    "Implementation of Dilate-attention block"
    def __init__(self, dim,chan, num_heads, mlp_ratio=0.4, qkv_bias=False,qk_scale=None, drop=0., attn_drop=0.01,
                 drop_path=0.,act_layer=nn.GELU, norm_layer=nn.LayerNorm, kernel_size=3, dilation=[1, 2],):
        super().__init__()
        self.dim = dim #输入特征维度
        self.num_heads = num_heads
        self.mlp_ratio = mlp_ratio
        self.kernel_size = kernel_size
        self.dilation = dilation #扩张率
        self.norm1 = norm_layer(dim)
        self.attn = MultiDilatelocalAttention(dim,chan, num_heads=num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale,
                                                attn_drop=attn_drop, kernel_size=kernel_size, dilation=dilation)

        # self.drop_path = DropPath(
        #     drop_path) if drop_path > 0. else nn.Identity()

        self.norm2 = norm_layer(dim)

        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim,
                       act_layer=act_layer, drop=drop)

    def forward(self, x):
        # x = x.permute(0, 2, 3, 1) #1444*1*1444*3
        # x = torch.tensor(x,dtype=torch.double)
        # x1 = x + self.drop_path(self.attn(self.norm1(x)))
        x1 = x + self.attn(self.norm1(x))#1444*3*1*1444
        # x1 = self.linear(x) #1444*3*1*512
        x2 = x1 + self.mlp(self.norm2(x1))
        # x = x.permute(0, 3, 1, 2)
        #B, C, H, W 1444*3*1*512
        return x2
class MultiDilatelocalAttention(nn.Module):
    "Implementation of Dilate-attention"

    def __init__(self, dim,chan, num_heads=2, qkv_bias=False, qk_scale=None,
                 attn_drop=0.,proj_drop=0., kernel_size=3, dilation=[1,2]):
        super().__init__()
        self.dim = dim
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.dilation = dilation
        self.kernel_size = kernel_size
        self.scale = qk_scale or head_dim ** -0.5
        self.num_dilation = len(dilation)
        assert num_heads % self.num_dilation == 0, f"num_heads{num_heads} must be the times of num_dilation{self.num_dilation}!!"
        self.qkv = nn.Conv2d(chan, chan * 3, 1, bias=qkv_bias)
        self.dilate_attention = nn.ModuleList(
            [DilateAttention(head_dim, qk_scale, attn_drop, kernel_size, dilation[i])
             for i in range(self.num_dilation)])
        self.proj = nn.Linear(dim, dim)
        # self.proj = nn.Linear(head_dim, head_dim)

        self.proj_drop = nn.Dropout(proj_drop)

    def forward(self, x):
        B, C, H, W = x.shape #1162*3*1*1162
        # x = x.permute(0, 3, 1, 2)# B, C, H, W #
        qkv = self.qkv(x).clone()
        qkv1=qkv.reshape(B, 3, self.num_dilation, C, H, W//self.num_dilation).permute(2, 1, 0, 3, 4, 5) #2*3*1162*3*1*581
        #num_dilation,3,B,C//num_dilation,H,W
        x_reshaped = x.reshape(B, self.num_dilation, C, H, W//self.num_dilation).permute(1, 0, 2, 3, 4 )  #2*1162*3*1*581
        # num_dilation, B, H, W, C//numlation
        output_list = []
        for i in range(self.num_dilation):
            x_i = self.dilate_attention[i](qkv1[i][0], qkv1[i][1], qkv1[i][2])# B, H, W,C//num_dilation 1444*3*1*361
            # x_reshaped[i] = x_i
            output_list.append(x_i.unsqueeze(0))
            x_reshaped = torch.cat(output_list, dim=0) #4*1444*3*1*361
        # x = x.permute(1, 2, 3, 0, 4).reshape(B, H, W, C)
        x1= x_reshaped.permute(1,2,3,4,0).reshape(B,C,H,W)
        x2 = self.proj(x1) #1444*3*1*1444
        x3 = self.proj_drop(x2)
        return x3

class DilateAttention(nn.Module):
    "Implementation of Dilate-attention"
    def __init__(self, head_dim, qk_scale=None, attn_drop=0., kernel_size=3, dilation=1):
        super().__init__()
        self.head_dim = head_dim
        self.scale = qk_scale or head_dim ** -0.5
        self.kernel_size=kernel_size
        self.unfold = nn.Unfold(kernel_size, dilation, dilation*(kernel_size-1)//2, 1)
        self.attn_drop = nn.Dropout(attn_drop)

    def forward(self,q,k,v):
        #B, C//3, H, W
        B,d,H,W = q.shape #1162*3*1*581

        # q = q.reshape([B, d//self.head_dim, self.head_dim, 1 ,H*W]).permute(0, 1, 4, 3, 2)  # B,h,N,1,d 32,1,64,1,4
        k= self.unfold(k).reshape([B,d,self.head_dim,self.kernel_size*self.kernel_size]) #144*3*361*9
        # k = self.unfold(k).reshape([B, d//self.head_dim, self.head_dim, self.kernel_size*self.kernel_size, H*W]).permute(0, 1, 4, 2, 3)  #B,h,N,d,k*k   32*1*64*4*9
        attn = (q @ k) * self.scale  # B,h,N,1,k*k 32*1*64*1*9  1444*3*1*9
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)
        v = self.unfold(v).reshape([B,d,self.kernel_size*self.kernel_size,self.head_dim]) #1444*3*9*361
        # v = self.unfold(v).reshape([B, d//self.head_dim, self.head_dim, self.kernel_size*self.kernel_size, H*W]).permute(0, 1, 4, 3, 2)  # B,h,N,k*k,d 32*1*64*9
        # x = (attn @ v).transpose(1, 2).reshape(B, H, W, d) #32*8*8*4
        x = (attn @ v).reshape(B,d,H,W) #1444*3*1*361
        return x

class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = in_features
        hidden_features = hidden_features
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.act = act_layer()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)

    def forward(self, x):
        x = self.fc1(x)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x
class encoderLayer(nn.Module):
    def __init__(self,dim, chan, num_heads,  encoder_dropout=0.05):
        super(encoderLayer, self).__init__()
        # d_ff = int(d_ff * d_model) #32
        self.attention_layer = DilateBlock(dim,chan,num_heads)

        # # point wise feed forward network
        # self.feedForward = nn.Sequential(
        #     nn.Linear(d_model, d_ff),
        #     nn.ReLU(),
        #     nn.Linear(d_ff, d_model)
        # )
        # self.dropout = nn.Dropout(encoder_dropout)
        # self.norm1 = nn.LayerNorm(d_model)# B,N,D
        # self.norm2 = nn.LayerNorm(d_model)

    def forward(self, x): #32*12*1*641
        new_x = self.attention_layer(x)
        # out1 = self.norm1(x + self.dropout(new_x))
        # out2 = self.norm2(out1 + self.dropout(self.feedForward(out1)))
        return new_x

class encoders(nn.Module):
    def __init__(self, dim,encoder_layers,num_heads,chan): #8
        super(encoders, self).__init__()
        self.encoder= nn.ModuleList([encoderLayer(dim,chan,num_heads) for i in range(encoder_layers)])#8层


    def forward(self, x):#1444*3*1*1444
        # x_original = x
        for encoder_layer in self.encoder:
            x = encoder_layer(x)
        # x = x+x_original
        return x

def to_2tuple(x):
    if isinstance(x, tuple):
        return x
    return (x, x)


#将输入图像划分为嵌入补丁
class PatchEmbed(nn.Module):
    """Image to Patch Embedding.
    """
    def __init__(self, img_size=224, in_chans=3, hidden_dim=16,
                 patch_size=4, embed_dim=96, patch_way=None):
        super().__init__()
        self.img_size = to_2tuple(img_size)
        patch_size = to_2tuple(patch_size)
        patches_resolution = [self.img_size[0] // patch_size[0], self.img_size[1] // patch_size[1]]
        self.num_patches = patches_resolution[0] * patches_resolution[1]
        # self.img_size = img_size
        assert patch_way in ['overlaping', 'nonoverlaping', 'pointconv'],\
            "the patch embedding way isn't exist!"
        if patch_way == "nonoverlaping":
            self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=patch_size, stride=patch_size)
        elif patch_way == "overlaping":
            self.proj = nn.Sequential(
                nn.Conv2d(in_chans, hidden_dim, kernel_size=3, stride=1,
                          padding=1, bias=False),  # 224x224
                nn.BatchNorm2d(hidden_dim),
                nn.GELU( ),
                nn.Conv2d(hidden_dim, int(hidden_dim*2), kernel_size=3, stride=2,
                          padding=1, bias=False),  # 112x112
                nn.BatchNorm2d(int(hidden_dim*2)),
                nn.GELU( ),
                nn.Conv2d(int(hidden_dim*2), int(hidden_dim*4), kernel_size=3, stride=1,
                          padding=1, bias=False),  # 112x112
                nn.BatchNorm2d(int(hidden_dim*4)),
                nn.GELU( ),
                nn.Conv2d(int(hidden_dim*4), embed_dim, kernel_size=3, stride=2,
                          padding=1, bias=False),  # 56x56
            )
        else:
            self.proj = nn.Sequential(
                nn.Conv2d(in_chans, hidden_dim, kernel_size=3, stride=2,
                          padding=1, bias=False),  # 112x112
                nn.BatchNorm2d(hidden_dim),
                nn.GELU( ),
                nn.Conv2d(hidden_dim, int(hidden_dim*2), kernel_size=1, stride=1,
                          padding=0, bias=False),  # 112x112
                nn.BatchNorm2d(int(hidden_dim*2)),
                nn.GELU( ),
                nn.Conv2d(int(hidden_dim*2), int(hidden_dim*4), kernel_size=3, stride=2,
                          padding=1, bias=False),  # 56x56
                nn.BatchNorm2d(int(hidden_dim*4)),
                nn.GELU( ),
                nn.Conv2d(int(hidden_dim*4), embed_dim, kernel_size=1, stride=1,
                          padding=0, bias=False),   # 56x56
            )

    def forward(self, x):
        B, C, H, W = x.shape
        # FIXME look at relaxing size constraints
        # assert H == self.img_size[0] and W == self.img_size[1], \
        #     f"Input image size ({H}*{W}) doesn't match model ({self.img_size[0]}*{self.img_size[1]})."
        x = self.proj(x)  # B, C, H, W
        return x

class Fusion(nn.Module):
    def __init__(self,ngraph,args):
        super(Fusion, self).__init__()

        self.gcn_x1_f = GCNConv(args.miRNA_number, args.miRNA_number)
        self.gcn_x2_f = GCNConv(args.miRNA_number, args.miRNA_number)
        self.gcn_x1_g = GCNConv(args.miRNA_number, args.miRNA_number)
        self.gcn_x2_g = GCNConv(args.miRNA_number, args.miRNA_number)
        self.gcn_y1_s = GCNConv(args.disease_number, args.disease_number)
        self.gcn_y2_s = GCNConv(args.disease_number, args.disease_number)
        self.gcn_y1_g = GCNConv(args.disease_number, args.disease_number)
        self.gcn_y2_g = GCNConv(args.disease_number, args.disease_number)
        self.fusion_m = CGAFusion(2)
        self.fusion_d = CGAFusion(2)
        self.drop_rate = args.drop_rate

        self.encoders = encoders(dim=ngraph, encoder_layers=args.encoder_layers , num_heads=2, chan=3)

        # self.dialateformer = DilateBlock(dim=ngraph, num_heads=4, mlp_ratio=4., qkv_bias=False,qk_scale=None, drop=0., attn_drop=0.,
        #          drop_path=0.,act_layer=nn.GELU, norm_layer=nn.LayerNorm, kernel_size=3, dilation=[1, 2,3,4],
        #          cpe_per_block=False)
        self.linear = nn.Linear(ngraph, 512)

        # self.patch_embed = PatchEmbed(img_size=ngraph, patch_size=4,
        #                               in_chans=3, embed_dim=96, patch_way='overlaping')

        self.mlp = nn.Sequential(nn.Linear(1024*2, 1024),
                                 nn.Linear(1024 , 512),

                                 # nn.LeakyReLU(),
                                 # nn.Dropout(self.drop_rate),
                                 nn.Linear(512,128),
                                 # nn.LeakyReLU(),
                                 # nn.Dropout(self.drop_rate),
                                 nn.Linear(128, 64),
                                 # nn.LeakyReLU(),
                                 # nn.Dropout(self.drop_rate),
                                 nn.Linear(64, 1), nn.Sigmoid())



    def forward(self,dataset,args):
        # x_m_f1 = torch.relu(self.gcn_x1_f(dataset['m_fs'].cuda(), dataset['m_fs_index'].cuda())).view(dataset['m_num'],1,1,dataset['m_num'])
        x_m_f1 = torch.relu(self.gcn_x1_f(dataset['m_fs'].cuda(), dataset['m_fs_index'].cuda()))
        x_m_f2 = torch.relu(self.gcn_x2_f(x_m_f1, dataset['m_fs_index'].cuda()))
        x_m_g1 = torch.relu(self.gcn_x1_g(dataset['m_gs'].cuda(), dataset['m_gs_index'].cuda()))
        x_m_g2 = torch.relu(self.gcn_x2_g(x_m_g1, dataset['m_gs_index'].cuda()))
        y_d_s1 = torch.relu(self.gcn_y1_s(dataset['d_ss'].cuda(), dataset['d_ss_index'].cuda()))
        y_d_s2 = torch.relu(self.gcn_y2_s(y_d_s1, dataset['d_ss_index'].cuda()))
        y_d_g1 = torch.relu(self.gcn_y1_g(dataset['d_gs'].cuda(), dataset['d_gs_index'].cuda()))
        y_d_g2 = torch.relu(self.gcn_y2_g(y_d_g1, dataset['d_gs_index'].cuda()))
        x_m_g = torch.stack((x_m_g1,x_m_g2),dim=0).unsqueeze(0)
        x_m_f = torch.stack((x_m_f1, x_m_f2), dim=0).unsqueeze(0)
        y_d_s = torch.stack((y_d_s1,y_d_s2),dim=0).unsqueeze(0)
        y_d_g = torch.stack((y_d_g1, y_d_g2), dim=0).unsqueeze(0)
        # x_m_g1 = torch.relu(self.gcn_x1_g(dataset['m_gs'].cuda(), dataset['m_gs_index'].cuda())).view(dataset['m_num'],1,1,dataset['m_num'])
        # y_d_s1 = torch.relu(self.gcn_y1_s(dataset['d_ss'].cuda(), dataset['d_ss_index'].cuda())).view(dataset['d_num'],1,1,dataset['d_num'])
        # y_d_g1 = torch.relu(self.gcn_y1_g(dataset['d_gs'].cuda(), dataset['d_gs_index'].cuda())).view(dataset['d_num'],1,1,dataset['d_num'])

        # m_fs = dataset['m_fs'].view(dataset['m_num'],1,1,dataset['m_num']) #788*1*1*788
        # m_gs = dataset['m_gs'].view(dataset['m_num'],1,1,dataset['m_num'])
        # d_ss = dataset['d_ss'].view(dataset['d_num'],1,1,dataset['d_num']) #374*1*1*374
        # d_gs = dataset['d_gs'].view(dataset['d_num'],1,1,dataset['d_num'])
        # fuison1_m = self.fusion_m(m_gs,m_fs).view(dataset['m_num'],dataset['m_num']) #788*788
        # fusion1_d = self.fusion_d(d_gs,d_ss).view(dataset['d_num'],dataset['d_num']) #374*374
        fuison1_m = self.fusion_m(x_m_g, x_m_f).view(dataset['m_num'], dataset['m_num'])  # 495*495
        fusion1_d = self.fusion_d(y_d_g, y_d_s).view(dataset['d_num'], dataset['d_num'])  # 374*374

        node_embeddings = torch.tensor(np.zeros((dataset['m_d'].shape[0]+dataset['m_d'].shape[1],dataset['m_d'].shape[0]+dataset['m_d'].shape[1]),dtype=float)).to(args.device)
        # node_embeddings[:dataset['m_d'].shape[0],:dataset['m_d'].shape[0]] = fuison1_m
        # node_embeddings[dataset['m_d'].shape[0]:,dataset['m_d'].shape[0]:] = fusion1_d
        # node_embeddings[:dataset['m_d'].shape[0],dataset['m_d'].shape[0]:] = dataset['m_d']
        # node_embeddings[dataset['m_d'].shape[0]:,:dataset['m_d'].shape[0]] = dataset['m_d'].T #1162*1162

        node_embeddings[:dataset['m_d'].shape[0],:dataset['m_d'].shape[0]] = fuison1_m
        node_embeddings[dataset['m_d'].shape[0]:,dataset['m_d'].shape[0]:] = fusion1_d
        node_embeddings[:dataset['m_d'].shape[0],dataset['m_d'].shape[0]:] = dataset['m_d']
        node_embeddings[dataset['m_d'].shape[0]:,:dataset['m_d'].shape[0]] = dataset['m_d'].T #1162*1162



        node_embeddings = node_embeddings.unsqueeze(1).to(torch.float32) #1162*1*1162

        node_embeddings_1 = self.linear(node_embeddings) #1162*1*512

        wl = torch.tensor(dataset['WL']).to(args.device).unsqueeze(1).to(torch.float32)
        lap = torch.tensor(dataset['lap']).to(args.device).unsqueeze(1).to(torch.float32)

        embeding1 = torch.cat((node_embeddings,wl),dim = 1)
        embeding2 = torch.cat((embeding1,lap),dim=1)#1444*3*1444
        embeding = embeding2.unsqueeze(2) #878*3*1*878
        embed = embeding.to(torch.float32) #878*3*1*878

        # patch_embed = self.patch_embed(embed)

        node_embed = self.encoders(embed).permute(1,0,2,3) #1444*3*1*1444
        # node_embed = self.encoders(embed)
        node_embed1 = self.linear(node_embed) #1444*3*1*512
        # ms_fus = MS_CAM(channels=3,r=2).to(args.device)
        # node_embed2 = ms_fus(node_embed1).permute(1,0,2,3)

        # sum_x_1 = (node_embed1[0] + node_embed1[1] + node_embed1[2]) / 3#1444*1*512
        sum_x_1 = (node_embed1[0] + node_embed1[1] + node_embed1[2])
        sum_x_1 = sum_x_1.squeeze()
        node_embeddings_1 = node_embeddings_1.squeeze()

        sum_x = torch.cat((sum_x_1,node_embeddings_1),1) #1444*1024

        # train_sample = train_index.int()
        # train_emb = torch.empty(0).to(args.device)
        # for i in range(len(train_index)):  #19913*2
        #     a = torch.cat((sum_x[train_index[i][0]], (sum_x[train_index[i][1]+rna_len])), dim=0).unsqueeze(0) #1*(1024*2)
        #     train_emb = torch.cat((train_emb, a), dim=0)
        #
        # train_score = self.mlp(train_emb)
        return sum_x





