# Author:wjy
# CreatTime: 2024/6/5
# FileName: tain_test
# Description: simple introduction of the code
import torch
from sklearn.metrics import accuracy_score

from main_hmdd20 import *
import xgboost as xgb
import torch.nn.functional as F

def cross_loss(S, A):
    # cross-view similarity matrix
    # loss of cross view
    L_cv = (A - S).pow(2).mean() #计算均方误差
    return L_cv


def train(model,  dataset,  optimizer, args):
    model.train()
    losses=[]
    for epoch in range(1, args.epochs + 1):
        # for i, (x, y) in enumerate(tr_set):
        optimizer.zero_grad()

            # x, y = x.to(args.device).to(torch.float32), y.to(args.device).to(torch.float32)
        sum_x = model(dataset ,  args)  # 97446,1   1444*1024
        rna_x = sum_x[:dataset['m_num']]
        dis_x = sum_x[dataset['m_num']:]
        similarity = torch.matmul(rna_x,dis_x.t()).to(args.device)
        adj_matrix = dataset['m_d'].cpu().numpy()
        np.fill_diagonal(adj_matrix, 1)
        A_sl = torch.tensor(adj_matrix).to(args.device)

        # loss = F.binary_cross_entropy_with_logits(similarity,A_sl)
        loss = cross_loss(similarity,A_sl)
        # score = score.reshape(447,218)
        # score = score.reshape(285,226)
        # loss = cross_entropy(score, train_lables)
        loss.backward()
        # pred = np.array([1 if p > 0.5 else 0 for p in score])
        # accuracy = accuracy_score(train_lables.cpu().numpy(), pred)
        losses.append(loss)
        # accuracies.append(accuracy)
        optimizer.step()

        # scheduler.step()
        if epoch %10==0 :
            print("第%d个epoch的学习率：%f" % (epoch, optimizer.param_groups[0]['lr']))
        print("epoch : %d, loss:%.2f" % (epoch, loss))
        # print(f'Epoch: {epoch + 1:03d}' f'   | Learning Rate {scheduler.get_last_lr()[0]:.6f}'f'    |  Loss : {loss:.2f}' )

    # picture(losses,args)
    return sum_x




        # return loss

        # train_reg_loss = train_epoch()


def test( model,dataset ,args):
    model.eval()
    # preds = []
    # labels = []
    # for x, y in tt_set:
    #     x,y= x.to(args.device).to(torch.float32),y.to(args.device).to(torch.float32)
    with torch.no_grad():

        # pred,valid_emb = model(dataset, valid_index, rna_len, dis_len, args)  # 最后一个batchsize是1 1*10256
        sum_x = model(dataset, args)
        # preds = pred.detach().cpu().numpy()
        # labels = valid_lables.detach().cpu().numpy()


        # preds.append(pred.detach().cpu())
        # labels.append(y.detach().cpu())
        # pred = FLAGS.loss_alpha*pred[0]+ (1-FLAGS.loss_alpha)*pred[1]
    # preds = torch.cat(preds, dim=0).numpy()
    # labels = torch.cat(labels, dim=0).numpy()
    # preds = torch.cat(preds, dim=0).numpy()
    # labels = torch.cat(labels, dim=0).numpy()
    # return labels, preds,valid_emb
    return sum_x